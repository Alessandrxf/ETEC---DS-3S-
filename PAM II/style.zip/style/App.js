import React from 'react';
import { StyleSheet, Text, View, ScrollView, Image, TextInput, Button } 
from 'react-native';


const login = () => {
    return (
      <ScrollView>
      <View>
      

           <Image

       source={{
         uri:"https://markspiscinas.com.br/wp-content/uploads/2021/03/perfil-de-avatar-de-mulher-no-icone-redondo_24640-14042.jpg"
       }}

       style={{
         
         width:100, height: 100,
         alignSelf: "center",
         marginBottom: 5,

       }}

       />

      <Text
       style={{
        fontSize: 40,
        alignSelf: "center",
        marginBottom: 60,
        fontFamily:"poppins", 
      }}
      >
      Login
      </Text>
       
       </View>
       <TextInput
       style={{
         height: 40,
         borderColor: "gray",
         borderWidth : 0.5,
         padding: 8,
         margin:10,

       }}
       defaultValue="E-mail: "
       />
       <TextInput
       style={{
         height: 35,
         borderColor: "gray",
         borderWidth : 0.5,
         padding: 8,
         margin:10,
        


       }}
       defaultValue="Senha: "
       />
      
       <Button 
        title="Entrar"
        color="#00994d"
        onPress={() => Alert.alert('Simple Button pressed')}
       />

       </ScrollView>
    )
    
}



export default login;